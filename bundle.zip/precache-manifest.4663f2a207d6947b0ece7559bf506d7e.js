self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8a796a7ce7ed114c26b477be15159912",
    "url": "/index.html"
  },
  {
    "revision": "4399a5b2ff4ede5c8001",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "4399a5b2ff4ede5c8001",
    "url": "/static/js/2.cf4032a1.chunk.js"
  },
  {
    "revision": "1c9a5c14c094f70c35a5a57a5770d494",
    "url": "/static/js/2.cf4032a1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7740856af66bde0e51fa",
    "url": "/static/js/main.bfd8692f.chunk.js"
  },
  {
    "revision": "d5d50483e52d53a4b219",
    "url": "/static/js/runtime-main.29d8161a.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);